package Module7.Part9.client;

public enum Card {
    CONNECT, USER_INFO, CHAT, ROOMS
}
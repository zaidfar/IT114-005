package Module7.Part9.common;

public abstract class Constants {
    public static final long DEFAULT_CLIENT_ID = -1L;
}